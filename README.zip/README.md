# escoladotrabalhador
- Este repositorio foi criado com o intuito de armazenar os projetos e arquivos dos cursos realizados pela escola do trabalhador 4.0, e realizar o controle de versão para eventuais estudos posteriores.

Autor - Pedro Lyrio